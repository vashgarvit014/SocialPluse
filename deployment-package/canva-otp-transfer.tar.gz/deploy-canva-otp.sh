#!/usr/bin/env bash
# Canva reviewer OTP-exemption deployment — auth-service only.
#
# ONE command to run this: sudo bash deploy-canva-otp.sh
#
# Design:
#   PHASE A (read-only)        — verify backups, verify prod file hash, take a
#                                 fresh Postgres backup, verify package checksums.
#   PHASE B (reversible writes) — write the two reviewed files into place.
#   PHASE C (THE ONLY DOWNTIME STEP) — hard interactive stop. Prints expected
#                                 downtime, requires you to type a literal
#                                 confirmation phrase, THEN rebuilds auth-service.
#   PHASE D (verification)     — container health, site reachability, reviewer
#                                 login without OTP, other-account OTP still
#                                 required, audit log entry present.
#   PHASE E (auto-rollback)    — any failure from Phase C onward restores the
#                                 pre-deploy source + image and re-verifies
#                                 health, then exits non-zero. Nothing before
#                                 Phase C can trigger a rollback (nothing's
#                                 been changed yet to roll back).
#
# Scope: touches ONLY services/auth-service/src/server.mjs,
# infrastructure/scripts/seed-canva-review-user.mjs, the auth-service env
# file (one appended line), the auth-service container/image. Nothing else —
# no IAM, SSH, DNS, Nginx, or other containers.
#
# The reviewer password is read interactively (hidden input), used in-process
# only, and unset immediately after use. It is never logged, never passed as
# a CLI arg, never written to disk.

set -euo pipefail

APP_DIR="/opt/socialpulse"
BACKUP_DIR="/opt/socialpulse-backups/20261019-084141"
STAGING_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"   # where this script + the 2 package files + CHECKSUMS.sha256 were uploaded
LOG_FILE="$BACKUP_DIR/deploy-canva-otp-$(date +%Y%m%d-%H%M%S).log"
EXPECTED_BASELINE_HASH="c42fd8fc3fd0644998f0e9218bebdb2730ba453338c6883c50bf4c826e0a2fc2"
CONFIRM_PHRASE="DEPLOY auth-service"

ROLLBACK_ARMED=0
log() { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOG_FILE"; }
fail() { log "ERROR: $*"; if [ "$ROLLBACK_ARMED" = "1" ]; then rollback; fi; exit 1; }

rollback() {
  log "=== AUTO-ROLLBACK TRIGGERED ==="
  sudo rm -rf "$APP_DIR/services/auth-service"
  sudo tar -xzf "$BACKUP_DIR/auth-service-src.tar.gz" -C "$APP_DIR"
  log "Source restored from $BACKUP_DIR/auth-service-src.tar.gz"
  PRE_IMAGE_TAG=$(cat "$BACKUP_DIR/auth-service-image-tag.txt" 2>/dev/null || true)
  if [ -n "${PRE_IMAGE_TAG:-}" ]; then
    (cd "$APP_DIR" && docker compose up -d --no-build auth-service 2>&1 | tee -a "$LOG_FILE") || true
    # If compose rebuilt a bad image, force the known-good tag back onto the running container:
    docker tag "$PRE_IMAGE_TAG" "$(docker inspect --format='{{.Config.Image}}' socialpulse-auth 2>/dev/null || echo socialpulse-auth-service:latest)" 2>&1 | tee -a "$LOG_FILE" || true
    (cd "$APP_DIR" && docker compose up -d --no-build auth-service 2>&1 | tee -a "$LOG_FILE") || true
  fi
  sleep 5
  docker ps --filter "name=auth" --format "table {{.Names}}\t{{.Status}}" | tee -a "$LOG_FILE"
  log "=== ROLLBACK COMPLETE — verify manually before trusting the site ==="
}

echo "Log: $LOG_FILE"
log "=== PHASE A: read-only preflight checks ==="

# A1. Backups the user already created (Step 2) must exist and verify.
[ -f "$BACKUP_DIR/auth-service-src.tar.gz" ] || fail "Missing $BACKUP_DIR/auth-service-src.tar.gz — Step 2 backup not found."
[ -f "$BACKUP_DIR/auth-service-src.tar.gz.sha256" ] || fail "Missing source backup checksum file."
sudo sha256sum -c "$BACKUP_DIR/auth-service-src.tar.gz.sha256" >>"$LOG_FILE" 2>&1 || fail "Source backup checksum mismatch — do not proceed."
log "Source backup verified OK."

PRE_IMAGE_TAG=$(cat "$BACKUP_DIR/auth-service-image-tag.txt" 2>/dev/null || true)
if [ -z "${PRE_IMAGE_TAG:-}" ]; then
  # Fall back to discovering a tag created by Step 2d's naming convention.
  PRE_IMAGE_TAG=$(docker images --format '{{.Repository}}:{{.Tag}}' | grep 'pre-canva-otp' | head -1 || true)
fi
[ -n "${PRE_IMAGE_TAG:-}" ] || fail "No backed-up auth-service image found (looked for $BACKUP_DIR/auth-service-image-tag.txt and any '*pre-canva-otp*' tag). Complete the Step 2 image backup (docker tag + verification) before running this script — do not proceed without a verified image backup."
docker image inspect "$PRE_IMAGE_TAG" >/dev/null 2>&1 || fail "Backed-up image tag $PRE_IMAGE_TAG recorded but not found on this host."
echo "$PRE_IMAGE_TAG" | sudo tee "$BACKUP_DIR/auth-service-image-tag.txt" >/dev/null
log "Docker image backup verified OK ($PRE_IMAGE_TAG)."

# A2. Re-confirm production file still matches the known baseline right now
#     (guards against drift between the earlier manual check and this run).
CURRENT_HASH=$(sudo sha256sum "$APP_DIR/services/auth-service/src/server.mjs" | awk '{print $1}')
[ "$CURRENT_HASH" = "$EXPECTED_BASELINE_HASH" ] || fail "Production server.mjs hash changed since baseline verification ($CURRENT_HASH). Stopping — do not blind-overwrite unexamined production changes."
log "Production server.mjs still matches expected baseline."

# A3. Verify the two package files were uploaded here and match the reviewed checksums.
PKG_SERVER="$STAGING_DIR/server.mjs"
PKG_SEED="$STAGING_DIR/seed-canva-review-user.mjs"
PKG_CHECKSUMS="$STAGING_DIR/CHECKSUMS.sha256"
[ -f "$PKG_SERVER" ] && [ -f "$PKG_SEED" ] && [ -f "$PKG_CHECKSUMS" ] || fail "Upload server.mjs, seed-canva-review-user.mjs and CHECKSUMS.sha256 into $STAGING_DIR via the browser SSH upload button first."
(cd "$STAGING_DIR" && sha256sum -c <(sed \
    -e "s#services/auth-service/src/server.mjs#server.mjs#" \
    -e "s#infrastructure/scripts/seed-canva-review-user.mjs#seed-canva-review-user.mjs#" \
    "$PKG_CHECKSUMS") >>"$LOG_FILE" 2>&1) || fail "Uploaded package files do not match the reviewed checksums — re-upload from the verified package."
log "Package file checksums verified OK."

# A4. Fresh, verified Postgres backup — taken now, not assumed to pre-exist.
DB_CONTAINER=$(docker ps --filter "name=db" --format "{{.Names}}" | head -1)
[ -n "$DB_CONTAINER" ] || fail "Could not find a running database container (filtered on name=db)."
PG_BACKUP_FILE="$BACKUP_DIR/postgres-$(date +%Y%m%d-%H%M%S).sql.gz"
log "Taking Postgres backup from container $DB_CONTAINER ..."
docker exec "$DB_CONTAINER" sh -c 'pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB"' | gzip | sudo tee "$PG_BACKUP_FILE" >/dev/null
[ -s "$PG_BACKUP_FILE" ] || fail "Postgres backup file is empty — aborting before any DB write."
zcat "$PG_BACKUP_FILE" | grep -q "CREATE TABLE.*users" || fail "Postgres backup does not contain expected 'users' table — refusing to trust it."
sudo sha256sum "$PG_BACKUP_FILE" | sudo tee "$PG_BACKUP_FILE.sha256" >/dev/null
log "Postgres backup verified OK: $PG_BACKUP_FILE"

log "=== PHASE A COMPLETE — all preflight checks passed. Nothing has been changed yet. ==="
ROLLBACK_ARMED=1   # from here on, any failure triggers automatic rollback

log "=== PHASE B: writing reviewed files into place ==="
sudo cp "$PKG_SERVER" "$APP_DIR/services/auth-service/src/server.mjs"
sudo cp "$PKG_SEED" "$APP_DIR/infrastructure/scripts/seed-canva-review-user.mjs" 2>/dev/null || \
  sudo install -D "$PKG_SEED" "$APP_DIR/infrastructure/scripts/seed-canva-review-user.mjs"
NEW_HASH=$(sha256sum "$APP_DIR/services/auth-service/src/server.mjs" | awk '{print $1}')
EXPECTED_NEW_HASH=$(grep "server.mjs" "$PKG_CHECKSUMS" | awk '{print $1}')
[ "$NEW_HASH" = "$EXPECTED_NEW_HASH" ] || fail "Post-write hash of server.mjs does not match the package — write may be corrupted."
log "Files written and verified in place."

log "=== Provisioning reviewer account (password read interactively, never logged) ==="
read -rsp "Reviewer password for canva.review@dotstark.com: " CANVA_REVIEW_PASSWORD
echo
[ -n "$CANVA_REVIEW_PASSWORD" ] || fail "No password entered."

AUTH_ENV_FILE=$(docker compose -f "$APP_DIR/docker-compose.yml" config 2>/dev/null | awk '/auth-service:/,/^  [a-z]/' | grep -A3 env_file | grep -oE '[^ ]+\.env[^ ]*|\.env\.[a-z]+' | head -1 || true)
AUTH_ENV_FILE="${AUTH_ENV_FILE:-$APP_DIR/.env.local}"
[ -f "$AUTH_ENV_FILE" ] || fail "Could not locate auth-service's env file (looked for $AUTH_ENV_FILE). Resolve manually before continuing — do not guess."

EXISTING_ID=$(docker exec "$DB_CONTAINER" sh -c "psql -U \"\$POSTGRES_USER\" -d \"\$POSTGRES_DB\" -tAc \"SELECT id FROM users WHERE lower(email)='canva.review@dotstark.com'\"" | tr -d '[:space:]')

if [ -n "$EXISTING_ID" ]; then
  log "Reviewer account already exists (id=$EXISTING_ID) — re-provisioning in place, id unchanged."
  REVIEW_ID="$EXISTING_ID"
else
  REVIEW_ID=$(cat /proc/sys/kernel/random/uuid)
  log "No existing reviewer account — will create with freshly generated id."
fi

DB_URL="postgresql://$(docker exec "$DB_CONTAINER" printenv POSTGRES_USER):$(docker exec "$DB_CONTAINER" printenv POSTGRES_PASSWORD)@localhost:5432/$(docker exec "$DB_CONTAINER" printenv POSTGRES_DB)"
docker cp "$APP_DIR/infrastructure/scripts/seed-canva-review-user.mjs" "$(docker ps --filter name=auth --format '{{.Names}}' | head -1)":/app/src/seed-canva-review-user.mjs

docker exec \
  -e CANVA_REVIEW_EMAIL="canva.review@dotstark.com" \
  -e CANVA_REVIEW_PASSWORD="$CANVA_REVIEW_PASSWORD" \
  -e CANVA_REVIEW_USER_ID="$REVIEW_ID" \
  -e DATABASE_URL="postgresql://$(docker exec "$DB_CONTAINER" printenv POSTGRES_USER):$(docker exec "$DB_CONTAINER" printenv POSTGRES_PASSWORD)@db:5432/$(docker exec "$DB_CONTAINER" printenv POSTGRES_DB)" \
  "$(docker ps --filter name=auth --format '{{.Names}}' | head -1)" \
  node src/seed-canva-review-user.mjs >>"$LOG_FILE" 2>&1 || fail "Seed script failed — see $LOG_FILE (password was not logged)."

unset CANVA_REVIEW_PASSWORD
log "Reviewer account provisioned: id=$REVIEW_ID (see log for non-secret confirmation output)."

if ! grep -q "^CANVA_REVIEW_USER_ID=" "$AUTH_ENV_FILE" 2>/dev/null; then
  echo "CANVA_REVIEW_USER_ID=$REVIEW_ID" | sudo tee -a "$AUTH_ENV_FILE" >/dev/null
  log "Appended CANVA_REVIEW_USER_ID to $AUTH_ENV_FILE."
else
  sudo sed -i "s/^CANVA_REVIEW_USER_ID=.*/CANVA_REVIEW_USER_ID=$REVIEW_ID/" "$AUTH_ENV_FILE"
  log "Updated existing CANVA_REVIEW_USER_ID in $AUTH_ENV_FILE."
fi

log "=== PHASE B COMPLETE ==="

echo
echo "================================================================"
echo " PHASE C — THE ONLY STEP THAT CAUSES DOWNTIME"
echo " About to run: docker compose up -d --build auth-service"
echo " Expected downtime: ~30-60s for the auth-service container only."
echo " Per LIVE_DEPLOY_RULES.md: confirm NO ONE is actively using the"
echo " site right now before continuing."
echo "================================================================"
read -rp "Type exactly '$CONFIRM_PHRASE' to proceed, anything else aborts safely (no rollback needed, nothing changed yet is destructive): " CONFIRM
[ "$CONFIRM" = "$CONFIRM_PHRASE" ] || { log "Not confirmed — stopping before rebuild. Files are already in place; rerun this script to resume, or restore from backup manually if you want to abandon."; exit 1; }

log "=== PHASE C: rebuilding auth-service only ==="
(cd "$APP_DIR" && docker compose up -d --build auth-service 2>&1 | tee -a "$LOG_FILE") || fail "docker compose rebuild failed."
sleep 8

log "=== PHASE D: verification ==="
HEALTH=$(docker inspect --format='{{.State.Health.Status}}' socialpulse-auth 2>/dev/null || echo unknown)
[ "$HEALTH" = "healthy" ] || fail "auth-service container not healthy (status=$HEALTH)."
log "Container healthy."

SITE_CODE=$(curl -s -o /dev/null -w "%{http_code}" https://socialpulse.dotstark.tech/)
[ "$SITE_CODE" = "200" ] || fail "Site returned $SITE_CODE, expected 200."
log "Site reachable (200)."

# Reviewer login — use the DB-stored account, not the password variable (already unset).
# At this point we re-prompt briefly only to execute the live-login proof; skip if undesired.
read -rsp "Re-enter reviewer password once more to verify live login (not logged): " VERIFY_PW
echo
RESP=$(docker exec "$(docker ps --filter name=auth --format '{{.Names}}' | head -1)" node -e "
fetch('http://localhost:4011/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({identifier:'canva.review@dotstark.com',password:process.env.VERIFY_PW})})
.then(r=>r.json()).then(j=>console.log(JSON.stringify(j)));
" 2>&1)
unset VERIFY_PW
echo "$RESP" | grep -q '"canvaReview":true' || fail "Reviewer login did not return canvaReview:true. Response: $RESP"
log "Reviewer login verified: no OTP required."

# Static proof the ID-based match (not email) is what's actually running, since
# we won't log into a real other user's account with their password here.
grep -q "user.id === CANVA_REVIEW_USER_ID" "$APP_DIR/services/auth-service/src/server.mjs" || fail "Deployed file does not contain the expected id-based match — unexpected content."
grep -q "user.email?.toLowerCase() === CANVA_REVIEW_EMAIL" "$APP_DIR/services/auth-service/src/server.mjs" && fail "Deployed file still contains the OLD email-based match — deployment did not take effect as expected."
log "Confirmed deployed logic matches by immutable user id only (old email-based match is gone)."

AUDIT_ROW=$(docker exec "$DB_CONTAINER" sh -c "psql -U \"\$POSTGRES_USER\" -d \"\$POSTGRES_DB\" -tAc \"SELECT 1 FROM auth_audit_logs WHERE event='CANVA_REVIEW_OTP_SKIPPED' AND user_id='$REVIEW_ID' ORDER BY created_at DESC LIMIT 1\"")
[ "$AUDIT_ROW" = "1" ] || fail "No CANVA_REVIEW_OTP_SKIPPED audit row found for this login — audit logging may be broken."
log "Audit log entry confirmed for this login."

echo
echo "NOTE: this script did not test a second, non-reviewer account against the"
echo "live site, because that would require a real user's password (not something"
echo "to use without consent) or creating a throwaway account (an unrequested"
echo "database write outside this change's scope). Instead it statically confirmed"
echo "the OLD email-based match is gone and the NEW id-based match is in place —"
echo "any account other than id=$REVIEW_ID structurally cannot satisfy it."
echo "If you want a live second-account proof, supply a dedicated test account's"
echo "credentials and I will add that check."
echo

log "=== PHASE D COMPLETE — deployment verified successful. ==="
log "Reviewer account id: $REVIEW_ID"
log "Rollback artifacts retained at: $BACKUP_DIR"
echo
echo "DONE. See $LOG_FILE for the full run record (no secrets were logged)."
